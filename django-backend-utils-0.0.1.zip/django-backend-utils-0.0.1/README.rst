
=====
backend_utils
=====



backend_utils is a tool kit with a Django backend. For each
question, visitors can choose between a fixed number of answers.

Detailed documentation is in the "docs" directory.

Quick start
-----------

1. Add "backend_utils" to your INSTALLED_APPS setting like this::

    INSTALLED_APPS = [
        ...

        'backend_utils',
    ]



